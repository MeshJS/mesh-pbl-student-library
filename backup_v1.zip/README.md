# Mesh PBL Student Library

This project accompanies the Mesh PBL Course. Additional details will be posted soon.

## Usage
```bash
git clone https://github.com/MeshJS/mesh-pbl-student-library
cd mesh-pbl-student-library
npm install
npm run dev
```


## Connect with us

Follow us on [Twitter](https://twitter.com/meshsdk) for updates.

Join our [Discord](https://discord.gg/Z6AH9dahdH) for any questions and suggestions.
