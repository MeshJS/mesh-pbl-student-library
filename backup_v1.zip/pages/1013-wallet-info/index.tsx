import MyWalletAssetComponent from "./MyWalletAssetComponent";
import MyWalletComponent from "./MyWalletComponent";

export default function WalletInfo() {
  return (
    <div>
      <div className="demo">
        <MyWalletComponent />
      </div>

      <div className="demo">
        <MyWalletAssetComponent />
      </div>
    </div>
  );
}
