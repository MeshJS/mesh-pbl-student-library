import MyWalletAssetComponent from "./MyWalletAssetComponent";
import MyWalletComponent from "./MyWalletComponent";

export default function WalletInfo() {
  return (
    <>
      <MyWalletComponent />
      <MyWalletAssetComponent />
    </>
  );
}
